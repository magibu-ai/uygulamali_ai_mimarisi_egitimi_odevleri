# Ek Ödev — Yapay Zeka Kimlik Eğitimi (Identity Fine-Tuning)

Bu klasördeki `identity_dataset.jsonl`, 1-2-3 numaralı ödevlerden **bağımsız**
ayrı bir eğitim sürecidir.

## Yapman gerekenler

1. `identity_dataset.jsonl` içindeki `[Hocanın Adı Soyadı]`, `[Öğrencinin Adı
   Soyadı]`, `[Ders/Bölüm Adı]` gibi köşeli parantez içindeki yer tutucuları
   kendi gerçek bilgilerinle değiştir.
2. İstersen 10-15 örneği daha ekleyerek (farklı ifade biçimleriyle "sen
   kimsin", "seni kim yaptı", "amacın ne" gibi sorular) veri setini
   zenginleştir — `dataset/augment_with_llm.py` script'i bu dosya için de
   kullanılabilir.
3. Bu veri setini, `finetune/unsloth_lora_finetune.py` script'indeki
   `DATASET_PATH` değişkenini bu dosyaya çevirerek **ayrı bir eğitim
   çalıştırması** olarak fine-tune et (ödev metninde "ayrı bir süreçtir"
   denildiği için domain veri setiyle karıştırmana gerek yok; istersen aynı
   modelin ayrı bir LoRA adaptörü olarak eğitip yayınlayabilirsin, istersen
   ana veri setiyle birleştirip tek adaptörde eğitebilirsin — ikisi de kabul
   edilir, hocanın tercihine göre seç).

## Format

Aynı `messages` (chat) formatı kullanılmıştır, böylece aynı eğitim script'i
hem domain hem kimlik veri seti için çalışır.
