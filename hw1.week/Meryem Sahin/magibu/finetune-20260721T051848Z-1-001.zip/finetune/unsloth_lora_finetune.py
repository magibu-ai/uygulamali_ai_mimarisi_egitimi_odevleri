"""
Ödev 3: Unsloth üzerinden Llama 3.2 modelini, Ödev 1'de hazırlanan
"tarihi yerler" veri setiyle LoRA ile fine-tune eder ve adaptörü
Hugging Face Hub'a yükler.

ÖNEMLİ: Bu script GPU gerektirir (Google Colab T4/A100, Kaggle GPU ya da
kendi CUDA'lı makinen). Bu chat ortamında GPU bulunmadığı için burada
ÇALIŞTIRAMADIM — kod, Colab/Kaggle'da doğrudan çalışacak şekilde yazıldı.

Kurulum (Colab):
    !pip install unsloth
    !pip install --upgrade --no-deps unsloth_zoo

Kullanım:
    python unsloth_lora_finetune.py
"""

import os
from unsloth import FastLanguageModel
from unsloth.chat_templates import get_chat_template
from datasets import load_dataset
from trl import SFTTrainer, SFTConfig

# ------------------------------------------------------------------
# 1) Ayarlar
# ------------------------------------------------------------------
MAX_SEQ_LENGTH = 2048
BASE_MODEL = "unsloth/Llama-3.2-3B-Instruct-bnb-4bit"  # istersen 1B veya 8B ile değiştir
DATASET_PATH = os.path.join(
    os.path.dirname(__file__), "..", "dataset", "tarihi_yerler_augmented.jsonl"
)
if not os.path.exists(DATASET_PATH):
    # augment edilmemişse ham/seed dosyaya düş
    DATASET_PATH = os.path.join(
        os.path.dirname(__file__), "..", "dataset", "tarihi_yerler_seed.jsonl"
    )

OUTPUT_DIR = "outputs"
HF_ADAPTER_REPO = "KULLANICI_ADIN/tarihi-yerler-llama32-lora"  # <-- değiştir

# ------------------------------------------------------------------
# 2) Modeli ve tokenizer'ı yükle (4-bit quantized, hızlı ve az VRAM)
# ------------------------------------------------------------------
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name=BASE_MODEL,
    max_seq_length=MAX_SEQ_LENGTH,
    dtype=None,          # otomatik seçim (bf16 destekleniyorsa kullanılır)
    load_in_4bit=True,
)

tokenizer = get_chat_template(tokenizer, chat_template="llama-3.1")

# ------------------------------------------------------------------
# 3) LoRA adaptörünü ekle
# ------------------------------------------------------------------
model = FastLanguageModel.get_peft_model(
    model,
    r=16,
    target_modules=[
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
    ],
    lora_alpha=16,
    lora_dropout=0,
    bias="none",
    use_gradient_checkpointing="unsloth",
    random_state=3407,
)

# ------------------------------------------------------------------
# 4) Veri setini yükle ve chat template'e uygula
# ------------------------------------------------------------------
dataset = load_dataset("json", data_files=DATASET_PATH, split="train")


def formatting_func(examples):
    texts = [
        tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=False)
        for msgs in examples["messages"]
    ]
    return {"text": texts}


dataset = dataset.map(formatting_func, batched=True)

# ------------------------------------------------------------------
# 5) Eğitim
# ------------------------------------------------------------------
trainer = SFTTrainer(
    model=model,
    tokenizer=tokenizer,
    train_dataset=dataset,
    dataset_text_field="text",
    max_seq_length=MAX_SEQ_LENGTH,
    args=SFTConfig(
        output_dir=OUTPUT_DIR,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        warmup_steps=10,
        num_train_epochs=3,
        learning_rate=2e-4,
        logging_steps=5,
        optim="adamw_8bit",
        weight_decay=0.01,
        lr_scheduler_type="linear",
        seed=3407,
        report_to="none",
    ),
)

trainer.train()

# ------------------------------------------------------------------
# 6) Kaydet + Hugging Face Hub'a yükle (sadece LoRA adaptörü)
# ------------------------------------------------------------------
model.save_pretrained("lora_adapter")
tokenizer.save_pretrained("lora_adapter")

model.push_to_hub(HF_ADAPTER_REPO, token=os.environ.get("HF_TOKEN"))
tokenizer.push_to_hub(HF_ADAPTER_REPO, token=os.environ.get("HF_TOKEN"))
print(f"LoRA adaptörü yüklendi: https://huggingface.co/{HF_ADAPTER_REPO}")

# ------------------------------------------------------------------
# 7) Hızlı test (inference)
# ------------------------------------------------------------------
FastLanguageModel.for_inference(model)
messages = [{"role": "user", "content": "Efes Antik Kenti hakkında bilgi verir misin?"}]
inputs = tokenizer.apply_chat_template(
    messages, tokenize=True, add_generation_prompt=True, return_tensors="pt"
).to(model.device)
output = model.generate(input_ids=inputs, max_new_tokens=200, use_cache=True)
print(tokenizer.decode(output[0], skip_special_tokens=True))
