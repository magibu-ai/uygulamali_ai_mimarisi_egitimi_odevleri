"""
Elle yazılan seed örnekleri (tarihi_yerler_seed.jsonl), her biri için farklı
soru kalıpları üreterek çoğaltır (data augmentation). Anthropic API kullanır.

Ödevdeki kural: "En az 10-20 örnek elle yazılıp model ile çoğaltılmalı."
Bu script, seed dosyasındaki her örneği aynı olgusal içerikle ama FARKLI
soru formülasyonlarıyla (ör. resmi/gündelik dil, farklı soru açısı) 4 kat
çoğaltır.

Kullanım:
    export ANTHROPIC_API_KEY=...   # kendi API anahtarınız
    pip install anthropic
    python augment_with_llm.py
"""

import json
import os
import time

import anthropic

SEED_PATH = os.path.join(os.path.dirname(__file__), "tarihi_yerler_seed.jsonl")
OUT_PATH = os.path.join(os.path.dirname(__file__), "tarihi_yerler_augmented.jsonl")
N_VARIANTS = 4  # her seed örnek için üretilecek varyasyon sayısı

client = anthropic.Anthropic()  # ANTHROPIC_API_KEY ortam değişkeninden okunur

AUGMENT_PROMPT = """Aşağıda bir tarihi yer hakkında bir soru-cevap örneği var.
Cevaptaki OLGUSAL BİLGİYİ DEĞİŞTİRMEDEN, sadece SORUYU {n} farklı şekilde
yeniden ifade et (biri gündelik dille, biri daha resmi, biri turist bakış
açısıyla, biri meraklı bir öğrenci gibi). Sadece JSON listesi döndür,
başka hiçbir açıklama ekleme. Format: ["soru1", "soru2", ...]

Orijinal soru: {question}
Orijinal cevap: {answer}
"""


def augment_one(question: str, answer: str, n: int = N_VARIANTS):
    msg = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=500,
        messages=[{
            "role": "user",
            "content": AUGMENT_PROMPT.format(n=n, question=question, answer=answer),
        }],
    )
    text = msg.content[0].text.strip()
    text = text.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return []


def main():
    with open(SEED_PATH, encoding="utf-8") as f:
        seeds = [json.loads(line) for line in f if line.strip()]

    augmented = []
    for ex in seeds:
        system = ex["messages"][0]["content"]
        question = ex["messages"][1]["content"]
        answer = ex["messages"][2]["content"]

        # orijinali de ekle
        augmented.append(ex)

        variants = augment_one(question, answer)
        for v in variants:
            augmented.append({
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": v},
                    {"role": "assistant", "content": answer},
                ]
            })
        time.sleep(0.5)

    with open(OUT_PATH, "w", encoding="utf-8") as f:
        for ex in augmented:
            f.write(json.dumps(ex, ensure_ascii=False) + "\n")

    print(f"{len(seeds)} seed -> {len(augmented)} toplam örnek -> {OUT_PATH}")


if __name__ == "__main__":
    main()
