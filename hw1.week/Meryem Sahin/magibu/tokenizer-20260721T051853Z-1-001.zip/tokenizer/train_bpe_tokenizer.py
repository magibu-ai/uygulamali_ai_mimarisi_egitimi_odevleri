"""
Ödev 2: Türkçe / tarihi yerler alanına özel bir BPE Tokenizer eğitir ve
Hugging Face Hub'a yükler.

Kurulum:
    pip install tokenizers transformers huggingface_hub datasets

Notlar:
- Kaliteli bir tokenizer için sadece 26-100 satırlık dataset yetersizdir;
  bu yüzden aşağıda hem kendi veri setinizi hem de daha büyük bir Türkçe
  metin korpusunu (ör. Wikipedia TR dökümü ya da alibayram/wikipedia-40-langs
  gibi genel bir Türkçe veri seti) birlikte kullanmanız önerilir. Sadece
  kendi küçük veri setinizle de eğitmek MÜMKÜNDÜR, fakat token kalitesi
  daha düşük olur.
"""

import os
from tokenizers import Tokenizer, models, normalizers, pre_tokenizers, trainers, decoders
from tokenizers.processors import TemplateProcessing

VOCAB_SIZE = 32000
MIN_FREQUENCY = 2
SPECIAL_TOKENS = ["<unk>", "<s>", "</s>", "<pad>", "<|system|>", "<|user|>", "<|assistant|>"]

OUT_DIR = os.path.join(os.path.dirname(__file__), "tarihi-yerler-bpe-tokenizer")


def get_training_corpus(paths):
    """Verilen dosyalardan (txt veya jsonl) metin akışı üretir."""
    import json
    for path in paths:
        if path.endswith(".jsonl"):
            with open(path, encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    ex = json.loads(line)
                    for m in ex.get("messages", []):
                        yield m["content"]
        else:
            with open(path, encoding="utf-8") as f:
                yield f.read()


def build_tokenizer(corpus_paths):
    tokenizer = Tokenizer(models.BPE(unk_token="<unk>"))

    # Türkçe için: küçük/büyük harf dönüşümü yapma (ı/İ, ş/ğ gibi harfleri
    # bozmamak için NFC normalizasyonu yeterli, lowercase KULLANMIYORUZ)
    tokenizer.normalizer = normalizers.NFC()
    tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tokenizer.decoder = decoders.ByteLevel()

    trainer = trainers.BpeTrainer(
        vocab_size=VOCAB_SIZE,
        min_frequency=MIN_FREQUENCY,
        special_tokens=SPECIAL_TOKENS,
        show_progress=True,
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
    )

    tokenizer.train_from_iterator(get_training_corpus(corpus_paths), trainer=trainer)

    tokenizer.post_processor = TemplateProcessing(
        single="<s> $A </s>",
        special_tokens=[
            ("<s>", tokenizer.token_to_id("<s>")),
            ("</s>", tokenizer.token_to_id("</s>")),
        ],
    )
    return tokenizer


def main():
    # Kendi veri setinizin yolu + (varsa) daha büyük ek bir Türkçe korpus
    corpus_paths = [
        os.path.join(os.path.dirname(__file__), "..", "dataset", "tarihi_yerler_seed.jsonl"),
        # os.path.join(os.path.dirname(__file__), "..", "dataset", "raw_corpus_tr.txt"),
    ]
    corpus_paths = [p for p in corpus_paths if os.path.exists(p)]

    tokenizer = build_tokenizer(corpus_paths)

    os.makedirs(OUT_DIR, exist_ok=True)
    tokenizer.save(os.path.join(OUT_DIR, "tokenizer.json"))

    # transformers uyumlu (PreTrainedTokenizerFast) formatında da kaydet
    from transformers import PreTrainedTokenizerFast
    fast_tokenizer = PreTrainedTokenizerFast(
        tokenizer_object=tokenizer,
        unk_token="<unk>",
        bos_token="<s>",
        eos_token="</s>",
        pad_token="<pad>",
    )
    fast_tokenizer.save_pretrained(OUT_DIR)
    print(f"Tokenizer kaydedildi: {OUT_DIR}")

    # Hızlı test
    test_text = "Göbeklitepe, Şanlıurfa'da bulunan dünyanın en eski tapınağıdır."
    encoded = tokenizer.encode(test_text)
    print("Örnek cümle:", test_text)
    print("Token sayısı:", len(encoded.tokens))
    print("Tokenlar:", encoded.tokens)


def push_to_hub(repo_id: str):
    """Eğitilen tokenizer'ı Hugging Face Hub'a yükler."""
    from transformers import PreTrainedTokenizerFast
    tok = PreTrainedTokenizerFast.from_pretrained(OUT_DIR)
    tok.push_to_hub(repo_id)
    print(f"Tokenizer yüklendi: https://huggingface.co/{repo_id}")


if __name__ == "__main__":
    main()
    # Yüklemek için (huggingface-cli login sonrası) aşağıdaki satırı aç:
    # push_to_hub("KULLANICI_ADIN/tarihi-yerler-bpe-tokenizer")
